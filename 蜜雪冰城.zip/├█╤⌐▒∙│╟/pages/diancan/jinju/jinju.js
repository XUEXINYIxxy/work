Page({
    data:{
        imgSrc:'/pages/diancan/image/jinju.jpg'
    }
  })