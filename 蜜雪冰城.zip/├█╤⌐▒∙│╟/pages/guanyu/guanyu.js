// pages/guanyu/guanyu.js
Page({
  fankui:function(){
      wx.navigateTo({
        url: '/pages/guanyu/fankui/fankui',
      })
  }
})