// pages/guanyu/li/li.js
Page({
    data:{
        src:"/pages/images/character/3.jpg",
        imgArray:[{
            mode:'aspectFit',
        }]
    }
})