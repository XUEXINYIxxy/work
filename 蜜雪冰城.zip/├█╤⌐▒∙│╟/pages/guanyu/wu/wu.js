// pages/guanyu/zhao/zhao.js
Page({
    data:{
        src:"/pages/images/character/1.JPG",
        imgArray:[{
            mode:'aspectFit',
        }]
    }
})