// pages/guanyu/xiong/xiong.js
Page({
    data:{
        src:"/pages/images/character/2.png",
        imgArray:[{
            mode:'aspectFit',
        }]
    }
})