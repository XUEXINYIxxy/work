// pages/huodong/huodong.js
Page({
    yaoyiyao:function(){
        wx.navigateTo({
          url: '',
        })
    },
})