// index.js
// 获取应用实例
const app = getApp()
function createRandomIndex(){
  return Math.floor(Math.random()*30);
}
Page({
  data: {
    index:0,
   imgArr:[
    '/pages/huodong/youhuiquan/image/gxhdyccjjh.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
    '/pages/huodong/youhuiquan/image/xxhg.jpg',
     '../youhuiquan/image/mfpsq.jpg',
     '../youhuiquan/image/mfpsq.jpg',
     '../youhuiquan/image/mfpsq.jpg',
     '../youhuiquan/image/mfpsq.jpg',
     '../youhuiquan/image/rnbdyj.jpg',
     '../youhuiquan/image/rnbdyj.jpg',
     '../youhuiquan/image/rnbdyj.jpg',
     '../youhuiquan/image/rnbdyj.jpg',
     '../youhuiquan/image/spq.jpg',  
     '../youhuiquan/image/spq.jpg',
     '../youhuiquan/image/spq.jpg',
     '../youhuiquan/image/spq.jpg', 
     '../youhuiquan/image/yydyj.jpg',
     '../youhuiquan/image/yydyj.jpg',
     '../youhuiquan/image/yydyj.jpg',
     '../youhuiquan/image/yydyj.jpg',
     '../youhuiquan/image/yydyj.jpg',
   ],
  },
  choujiang:function(){
    this.setData({
      index:createRandomIndex()
    })
    wx.showToast({
      title: '恭喜中奖',
      icon:'success',
      duration:2000
    })
  }
})