// pages/index/index.js
Page({
  data: {
    Imgs: [{
        url: '/pages/images/swiper/1.png'
      },
      {
        url: '/pages/images/swiper/2.jpg'
      },
      {
        url: '/pages/images/swiper/3.png'
      },
      {
        url: '/pages/images/swiper/4.png'
      }
    ],
  },
  
  search:function(){
    wx.navigateTo({
      url: '/pages/index/search/search',
    })
  },

   diancan:function(){
    wx.switchTab({
      url: '/pages/diancan/diancan',
    })
   },

   huodong:function() {
    wx.switchTab({
      url: '/pages/huodong/huodong',
    })
  },

 guanyu:function() {
    wx.switchTab({
      url: '/pages/guanyu/guanyu',
    })
  },
})
 

 